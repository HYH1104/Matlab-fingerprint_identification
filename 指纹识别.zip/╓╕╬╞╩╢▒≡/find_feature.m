function [X1,Y1,X2,Y2]=find_feature(I,x0,y0,radius)
[M,N]=size(I);
t=0;
k=0;
for i=2:M-1
    for j=2:N-1
        if I(i,j)==0
            n=I(i-1,j-1)+I(i-1,j)+I(i-1,j+1)+I(i,j-1)+I(i,j+1)+I(i+1,j-1)+I(i+1,j)+I(i+1,j+1);
            if (n==5)%�ֲ��
                t=t+1;
                x1(t)=j;
                y1(t)=i;
            end
            if (n==7)%�˵�
                k=k+1;
                x2(k)=j;
                y2(k)=i;
            end
        end
    end
end
%ȥ������Ͻ���������
for i=1:t-1
    for j=i+1:t
        d=sqrt((x1(i)-x1(j))^2+(y1(i)-y1(j))^2);
%         if d<20 
%             x1(i)=-1;y1(i)=-1;x1(j)=-1;y1(j)=-1;
%         end
    end
end
for i=1:k-1
    for j=i+1:k
        d=sqrt((x2(i)-x2(j))^2+(y2(i)-y2(j))^2);
%         if d<10 
%             x2(i)=-1;y2(i)=-1;x2(j)=-1;y2(j)=-1;
%         end
    end
end
%�������ĵ�뾶֮�ڵĵ�
for i=1:t
%     d(i)=sqrt((x1(i)-x0)^2+(y1(i)-y0)^2);
%      if(d(i)<radius)
    X1(i)=x1(i);
    Y1(i)=y1(i);
%      end
end
for i=t:1000
%     d(i)=sqrt((x1(i)-x0)^2+(y1(i)-y0)^2);
%      if(d(i)<radius)
    X1(i)=0;
    Y1(i)=0;
%      end
end
for i=1:k
     d(i)=sqrt((x2(i)-x0)^2+(y2(i)-y0)^2);
     if(d(i)<radius)
    X2(i)=x2(i);
    Y2(i)=y2(i);
     end
end
end
