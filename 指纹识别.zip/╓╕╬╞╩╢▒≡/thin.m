function y=thin(x)
I=ordfilt2(x,5,ones(3,3));%��ָ��ͼ�����3��3�˲�
u=I;
[m,n]=size(u);
for x=2:m-1
    for y=2:n-1
        if u(x,y)==0
            if u(x,y-1)+u(x-1,y)+u(x,y+1)+u(x+1,y)>=3
                u(x,y)=1;
            else
                u(x,y)=u(x,y);
            end
        end
    end
end
for a=2:m-1
    for b=2:n-1
        if u(a,b)==1
            if abs(u(a,b+1)-u(a-1,b+1))+abs(u(a-1,b+1)-u(a-1,b))+abs(u(a-1,b)-u(a-1,b-1))+abs(u(a-1,b-1)-u(a,b-1))+abs(u(a,b-1)-u(a+1,b-1))+abs(u(a+1,b-1)-u(a+1,b))+abs(u(a+1,b)-u(a+1,b+1))+abs(u(a+1,b+1)-u(a,b+1))~=1%Ѱ�Ҷ˵�
                if (u(a,b+1)+u(a-1,b+1)+u(a-1,b))*(u(a,b-1)+u(a+1,b-1)+u(a+1,b))+(u(a-1,b)+u(a-1,b-1)+u(a,b-1))*(u(a+1,b)+u(a+1,b+1)+u(a,b+1))==0 %ȥ��ë�̺Ϳն�
                    u(a,b)=0;
                end
            end
        end
    end
end
v=~u;
w=bwmorph(v,'thin',Inf);%��ͼ�����ϸ��
for x=2:m-1
    for y=2:n-1
        if w(x,y)==1
            if (w(x-1,y)==1&&w(x,y-1)==1)||(w(x-1,y)==1&&w(x,y+1)==1)||(w(x,y-1)==1&&w(x+1,y)==1)||(w(x+1,y)==1&&w(x,y+1)==1)
                w(x,y)=0;
            end
        end
    end
end
y=w;
