function y=normalize(x)
%��ָ��ͼ����й�һ������
x = imresize(x,[320,320],'bilinear');%˫���Բ�ֵ����
x1=double(x);
[a,b,~]=size(x);
m=10;
a1=a/m;%�зֿ���
b1=b/m;%�зֿ���
M0=mean2(x1);
V=std2(x1);
V0=V*V;
M1=80;
V1=6000;
T=60;
a3=1;%���ƶ�����λ��
b3=1;%���ƶ�����λ��
for i=1:a
    for j=1:b
        if x1(i,j)>M0
            result(i,j)=M1+sqrt(V1*((x1(i,j)-M0)*(x1(i,j)-M0))/V0);
        else
            result(i,j)=M1-sqrt(V1*((x1(i,j)-M0)*(x1(i,j)-M0))/V0);
        end
    end
end

for k=1:a1
    for l=1:b1
        M2=mean2(result(a3:(a3+m-1),b3:(b3+m-1)));%��ֵ
        V2=std2(result(a3:(a3+m-1),b3:(b3+m-1)));%����
        V3=V2*V2;

        if V3<1000
            for i1=a3:a3+m-1
                for j1=b3:b3+m-1
                    result(i1,j1)=255;
                end
            end
        end

        if V2==0
            for i1=a3:a3+m-1
                for j1=b3:b3+m-1
                    result(i1,j1)=255;
                end
            end
        else
            Th=M2/V2;
            if Th>T
                for i1=a3:a3+m-1
                    for j1=b3:b3+m-1
                        result(i1,j1)=255;
                    end
                end
            end
        end
        b3=b3+m;
    end
    b3=1;
    a3=a3+m;
end
y=result;

